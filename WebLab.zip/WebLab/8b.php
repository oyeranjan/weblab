<html>
<body>
<?php
	$matrix1=[[1,2,3],[4,5,6],[7,8,9]];
	$matrix2=[[1,2,3],[4,5,6],[7,8,9]];
	echo "<br><h2>Sum</h2>";
	for($i=0;$i<=2;$i++)
	{
		for($j=0;$j<=2;$j++)
		{
		$sum=$matrix1[$i][$j]+$matrix2[$i][$j];
		echo $sum." ";
		}
		echo "<br>";
	}
	echo "<h2>Multiplication</h2>";
	for($i=0;$i<=2;$i++)
	{
		for($j=0;$j<=2;$j++)
		{
			$matrix3[$i][$j]=0;
			for($k=0;$k<=2;$k++)
			{
				$matrix3[$i][$j]+=$matrix1[$i][$k]*$matrix2[$k][$j];
			}
			echo $matrix3[$i][$j]." ";
		}
		echo "<br>";
	}
	echo "<br><h2>Transpose of Matrix1 is:</h2><br>";
	for($i=0;$i<=2;$i++)
	{
		for($j=0;$j<=2;$j++)
		{
			echo $matrix1[$j][$i]." ";
		}
		echo "<br>";
	}
?>
</body>
</html>

	