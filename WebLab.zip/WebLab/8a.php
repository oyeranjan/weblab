<!DOCTYPE html>
<html>
<title> CALCULATOR</title>
<body style="text-align:center; border:solid 2px black; height:50%;width:50%; margin-left:25%;">
<h1>SIMPLE CALCULATOR</h1>
<form method="post">
	Input1: <input type="text" name="first"/><br><br>
	Input2: <input type="text" name="second"/><br><br>
	<input type="radio" name="op" value="add">Addition <br>
	<input type="radio" name="op" value="sub">Subtract<br>
	<input type="radio" name="op" value="mul">Multiply<br>
	<input type="radio" name="op" value="div">Division<br><br>
	<button type="submit" name="answer">Calculate</button>
</form>
<p>The Answer is:
	<?php
		$x=(int)$_POST['first'];
		$y=(int)$_POST['second'];
		if($_POST['op']=="add")
			print $x+$y;
		else if($_POST['op']=="sub")
			print $x-$y;
		else if($_POST['op']=="mul")
			print $x*$y;
		else if($_POST['op']=="div")
			if($y==0)
				print "Can't Divide By Zero";
			else
				print $x/$y;
	?>
</p>
</body>
</html>
		