<?php
	$file = "count.txt";
	$c = file_get_contents($file);
	echo("No. of visitors = ".$c);
	file_put_contents($file,$c+1);
?>