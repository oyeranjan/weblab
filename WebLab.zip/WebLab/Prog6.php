<!DOCTYPE HTML>
<html>
<meta http-equiv="refresh" content="1"/>
<head>
<style>
	p{
		position:absolute;
		left:40%;
		top:50%;
		border-radius: 10px;
		border-style: solid;
		background-color: lightblue;
		padding: 7px;
		text-align: center;
	}
</style>
</head>
<body bgcolor='lightgrey'>
<p> Current Time: 
	<?php
		date_default_timezone_set("Asia/Kolkata");
		echo date("h:i:s A");
	?>
</p>
</body>
</html>