<?php

$states = "Mississippi Alabama Texas Massachusetts Kansas";
$state1=explode(' ',$states);
echo '<p><b>Original Array:</b></p>';
for($i=0;$i<count($state1);$i++){
	echo ('state['.$i.'] = '.$state1[$i].'<br>');
}

for($i=0;$i<count($state1);$i++){
	if(preg_match('/xas$/',$state1[$i]))
		$statelist[0]=$state1[$i];
	if(preg_match('/^K.*s$/i',$state1[$i]))
		$statelist[1]=$state1[$i];
	if(preg_match('/^M.*s$/',$state1[$i]))
		$statelist[2]=$state1[$i];
	if(preg_match('/a$/',$state1[$i]))
		$statelist[3]=$state1[$i];
	
}

echo '<br><b>Output Array:</b><br><br>';
for($i=0;$i<count($statelist);$i++){
	echo ('statelist['.$i.'] = '.$statelist[$i].'<br>');
}



















?>