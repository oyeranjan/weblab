<?php

	function print_mat($a){
		foreach($a as $b){
			foreach($b as $c){
				echo($c.' ');
			}
			echo("<br/>");
		}
		echo("<br>");
	}

	$a=[[1,2,3],[4,5,6],[7,8,9]];
	$b=[[1,2,3],[4,5,6],[7,8,9]];
	echo 'Matrix 1:<br>';
	print_mat($a);
	echo 'Matrix 2:<br>';
	print_mat($b);
	
	for($i=0;$i<3;$i++)
		for($j=0;$j<3;$j++)
			$c[$i][$j]=$a[$j][$i];
		
	echo 'Transpose of Matrix 1:<br>';
	print_mat($c);
	
	for($i=0;$i<3;$i++)
		for($j=0;$j<3;$j++)
			$c[$i][$j]=$a[$i][$j]+$b[$i][$j];
		
	echo 'Addition of Matrix 1 and Mtrix 2:<br>';
	print_mat($c);	
	
	for($i=0;$i<3;$i++){
		for($j=0;$j<3;$j++){
			$c[$i][$j]=0;
			for($k=0;$k<3;$k++){
				$c[$i][$j]+=$a[$i][$k]*$b[$k][$j];
			}
		}
	}
	echo 'Multiplication:<br>';
	print_mat($c);	
		
?>