<?php
	$file=fopen("demo.txt","r");
	$visit=(int)fgets($file);
	fclose($file);
	$visit++;
	print "<h2>Total Number of Visit: ".$visit."</h2>";
	$file=fopen("demo.txt","w");
	fputs($file,$visit);
	fclose($file);	
?>
