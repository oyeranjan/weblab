<?php
include "selectionsort.php";
$hostname="localhost";
$username="root";
$password="";
$dbname="student_record";

$conn=mysqli_connect($hostname,$username,$password,$dbname);
if($conn -> connect_error){
	die("Connection Failed".$conn -> connect_error);
}

$sql="select usn,name,branch,sem from stud_data";
$res=$conn->query($sql);
$data=array();
if($res->num_rows>0){
	while($row=$res->fetch_assoc())
		$data[]=$row;
}
$data=s_sort($data,count($data));
echo '<table cell-padding=5 border=3>';
echo '<tr><th>USN</th><th>NAME</th><th>BRANCH</th><th>SEM</th></tr>';
for($i=0;$i<count($data);$i++){
	echo '<tr><td>'.$data[$i]["usn"].'</td><td>'.$data[$i]["name"].'</td><td>'.$data[$i]["branch"].'</td><td>'.$data[$i]["sem"].'</td></tr>';
}
echo '</table>';
$conn->close();	


?>