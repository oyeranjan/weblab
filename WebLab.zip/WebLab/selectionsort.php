<?php
function s_sort($a,$len){
for($i=0;$i<$len;$i++){
	$low=$i;
	for($j=$i+1;$j<$len;$j++){
		if($a[$j]<$a[$low])
			$low=$j;
	}
	if($a[$i]>$a[$low]){
		$temp=$a[$i];
		$a[$i]=$a[$low];
		$a[$low]=$temp;
	}
}
return $a;
}

?>